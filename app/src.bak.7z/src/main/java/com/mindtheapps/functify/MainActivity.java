package com.mindtheapps.functify;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.mindtheapps.functify.Functify.FBuilder;

import static com.mindtheapps.functify.Functify.FBuilder.runAsync;
import static com.mindtheapps.functify.Functify.FBuilder.runOnMain;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView text = (TextView) findViewById(R.id.text);

        text.setText("Starting flow");

        example3(text);

    }

    private void example1(final TextView text) {
        FBuilder fb = Functify.newFlow();
        fb.runAsync(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                try {
                    Thread.sleep(1000); // lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "Supposed to run on a worker thread:");
                Functify.printDebug();
                b.putString("hello", "there");

                return b;
            }
        }).runOnMain(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'there'. got " + b.get("hello"));
                b.putString("state", "ok");
                text.setText("Back to main: got " + b.get("hello"));
                return b;
            }
        }).runAsync(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on a worker thread again:");
                Functify.printDebug();
                try {
                    Thread.sleep(2000); // lots and lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "And the bundle should say 'ok'. got " + b.get("state"));
                b.putString("state", "complete");

                return b;
            }
        }).runOnMain(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'complete'. got " + b.get("state"));
                text.setText("Back to main: got state " + b.get("state"));
                return b;
            }
        }).execute();

    }

    private void example2(final TextView text) {
        FBuilder fb = Functify.newFlow();
        fb.runAsync(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                try {
                    Thread.sleep(1000); // lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "Supposed to run on a worker thread:");
                Functify.printDebug();
                b.putString("hello", "there");


                //  text.setText("Should crash (wrong thread)"); // indeed crashed

                return b;
            }
        });
        fb.runOnMain(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'there'. got " + b.get("hello"));
                b.putString("state", "ok");
                text.setText("Back to main: got " + b.get("hello"));
                return b;
            }
        });
        fb.runAsync(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on a worker thread again:");
                Functify.printDebug();
                try {
                    Thread.sleep(2000); // lots and lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "And the bundle should say 'ok'. got " + b.get("state"));
                b.putString("state", "complete");

                return b;
            }
        });
        fb.runOnMain(new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'complete'. got " + b.get("state"));
                text.setText("Back to main: got state " + b.get("state"));
                return b;
            }
        });
        fb.execute();

    }

    private void example3(final TextView text) {
        FBuilder bld = Functify.newFlow();

        runAsync(bld, new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                try {
                    Thread.sleep(1000); // lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "Supposed to run on a worker thread:");
                Functify.printDebug();
                b.putString("hello", "there");


                //  text.setText("Should crash (wrong thread)"); // indeed crashed

                return b;
            }
        });
        runOnMain(bld, new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'there'. got " + b.get("hello"));
                b.putString("state", "ok");
                text.setText("Back to main: got " + b.get("hello"));
                return b;
            }
        });
        runAsync(bld, new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on a worker thread again:");
                Functify.printDebug();
                try {
                    Thread.sleep(2000); // lots and lots of work
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "And the bundle should say 'ok'. got " + b.get("state"));
                b.putString("state", "complete");

                return b;
            }
        });
        runOnMain(bld, new Functify.Func(null) {
            @Override
            public Bundle onExecute(Bundle b) {
                Log.d(TAG, "Supposed to run on the main thread.");
                Functify.printDebug();
                Log.d(TAG, "And the bundle should say 'complete'. got " + b.get("state"));
                text.setText("Back to main: got state " + b.get("state"));
                return b;
            }
        });
        bld.execute();

    }


}
