package com.mindtheapps.functify;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.annotation.IntDef;
import android.util.Log;

import java.lang.annotation.Retention;
import java.util.ArrayList;

import static java.lang.annotation.RetentionPolicy.SOURCE;

/**
 * Created by amir uval on 5/10/17.
 * amir@mindtheapps.com
 */
public final class Functify {

    /**
     * @THREAD_TYPE
     */
    public static final int TH_ANY = 0;
    public static final int TH_UI = 1;
    public static final int TH_WORKER = 2;
    public static final int TH_POOL_WORKER = 3;
    static final CallbackingRunnable cbr = new CallbackingRunnable();
    private static final String TAG = Functify.class.getSimpleName();
    private static final Handler sAsyncHandler;
    private static final Handler sMainHandler;
    private static final HandlerThread sAsyncHandlerThread = new HandlerThread("WorkerThread");

    static {
        sAsyncHandlerThread.start();
        sAsyncHandler = new Handler(sAsyncHandlerThread.getLooper());
        sMainHandler = new Handler(Looper.getMainLooper());

    }

    public static FBuilder newFlow() {
        return new FBuilder();
    }

    public static
    @THREAD_TYPE
    int getThreadType() {
        return Looper.myLooper().equals(Looper.getMainLooper()) ? TH_UI : TH_WORKER;
    }

    public static void printDebug() {
        Log.d(TAG, ">> [running on " + (getThreadType() == TH_UI ? " the main thread]:" : " a worker thread @" + Looper.myLooper().hashCode() +
                "]:"));
    }

    /**
     * Session wrapper id
     */
    @Retention(SOURCE)
    @IntDef({
            TH_ANY,//0
            TH_UI,//1
            TH_WORKER,//2
            TH_POOL_WORKER, //3
    })
    public @interface THREAD_TYPE {
    }

    interface Callback {
        void onComplete();

        void onException(Exception e);
    }

    public static class FBuilder {

        ArrayList<Func> runnables = new ArrayList<>();

        /**
         * same as the non static alternative, but allows less verbose code when using static import
         * @param b
         * @param func
         */
        public static void runOnMain(FBuilder b, Func func) {
            func.whereToRun = TH_UI;
            b.runnables.add(func);
        }

        public static void runAsync(FBuilder b, Func func) {
            // run the runnable on a worker thread and return this FBuilder when done
            func.whereToRun = TH_WORKER;
            b.runnables.add(func);
        }

        public void execute() {
            int index = 0;
            Bundle b = new Bundle();
            execute(b, index);
        }

        private void execute(final Bundle b, final int i) {
            // starting with an empty bundle
            if (i >= runnables.size()) {
                // flow is complete
                return;
            }
            cbr.func = runnables.get(i);
            cbr.b = b;
            cbr.cb = new Callback() {
                @Override
                public void onComplete() {
                    // go to next
                    execute(b, i + 1);
                }

                @Override
                public void onException(Exception e) {
                    throw new RuntimeException(e);
                }
            };
            if (cbr.func.whereToRun == TH_WORKER) {
                sAsyncHandler.post(cbr);
            } else if (cbr.func.whereToRun == TH_UI) {
                sMainHandler.post(cbr);
            } else { //TH_ANY, pool
                // run on the current thread, or on a thread pool
                // todo
                throw new RuntimeException("todo");
            }

        }

        public FBuilder runAsync(Func func) {
            // run the runnable on a worker thread and return this FBuilder when done
            func.whereToRun = TH_WORKER;
            runnables.add(func);
            return this;
        }

        public FBuilder runAllAsync(Func... funcs) {
            // run the runnable on a worker thread and return this FBuilder when done
            for (Func f : funcs) {
                f.whereToRun = TH_POOL_WORKER;
                runnables.add(f);
            }
            return this;
        }

        public FBuilder runOnMain(Func func) {
            func.whereToRun = TH_UI;
            runnables.add(func);
            return this;
        }

        public FBuilder runOnAny(Func func) {
            func.whereToRun = TH_ANY;
            runnables.add(func);
            return this;
        }
    }

    public abstract static class Func {
        private final Func f;
        private
        @THREAD_TYPE
        int whereToRun;

        public Func(Func f) {
            this.f = f;
        }

        public abstract Bundle onExecute(Bundle b);

    }

    private static class CallbackingRunnable implements Runnable {
        Func func;
        Bundle b;
        Callback cb;

        @Override
        public void run() {
            try {
                // b can be modified inside the onExecute
                func.onExecute(b);
                cb.onComplete();
            } catch (Exception e) {
                cb.onException(e);
            }
        }
    }
}
